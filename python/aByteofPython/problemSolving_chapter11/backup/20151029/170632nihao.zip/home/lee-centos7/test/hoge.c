/*
 * =====================================================================================
 *
 *       Filename:  hoge.c
 *
 *    Description:  
 *
 *        Created:  10/16/2015 03:56:10 PM
 *       Compiler:  gcc
 *
 *         Author:  Alan Lee , 1127259111@qq.com
 *
 * =====================================================================================
 */
#include <stdio.h>
#include <stdlib.h>

struct Hoge {
    int a;
    double d1;
    char c;
    double d2;
};


int main(void)
{
    struct Hoge hoge;
    printf("size of Hoge is : %d \n", sizeof(hoge));
    printf("the start address of hoge is  : %p\n", &hoge);
    printf("the start address of a is     : %p\n", &hoge.a);
    printf("the start address of d1 is    : %p\n", &hoge.d1);
    printf("the start address of c is     : %p\n", &hoge.c);
    printf("the start address of d2 is    : %p\n", &hoge.d2);
    printf("\nsize of int is : %d\n", sizeof(int));

    return EXIT_SUCCESS;
}





/*
 * =====================================================================================
 *
 *       Filename:  another.c
 *
 *    Description:  
 *
 *        Created:  10/16/2015 04:26:25 PM
 *       Compiler:  gcc
 *
 *         Author:  Alan Lee , 1127259111@qq.com
 *
 * =====================================================================================
 */
#include <stdio.h>
#include <stdlib.h>

//#pragma pack(2)

struct B {
    char b;
    int a;
    short c;
};

//#pragma pack()

int main(void)
{
    struct B b;
    printf("size of B is : %d\n", sizeof(b));

    return EXIT_SUCCESS;
}

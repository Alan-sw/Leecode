/*
 * =====================================================================================
 *
 *       Filename:  perror.c
 *
 *    Description:  test for perror
 *
 *        Created:  10/19/2015 11:38:57 AM
 *       Compiler:  gcc
 *
 *         Author:  Alan Lee , 1127259111@qq.com
 *
 * =====================================================================================
 */

/************************************************************
    perror is the same as below

    peror(str) == 

    if (str) {
        fprintf(stderr, "%s: %s\n", str, strerror(errno));
    } else {
        fprintf(stderr, "%s\n", strerror(errno));
    }
*************************************************************/



#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
    perror("this is a test of perror");

    return EXIT_SUCCESS;
}

/*
 * =====================================================================================
 *
 *       Filename:  print127.c
 *
 *    Description:  print 127
 *
 *        Created:  10/19/2015 02:36:59 PM
 *       Compiler:  gcc
 *
 *         Author:  Alan Lee , 1127259111@qq.com
 *
 * =====================================================================================
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    printf("%c\n",127);

    return EXIT_SUCCESS;
}

/*
 * =====================================================================================
 *
 *       Filename:  reannouce.c
 *
 *    Description:  
 *
 *        Created:  10/17/2015 08:28:39 PM
 *       Compiler:  gcc
 *
 *         Author:  Alan Lee , 1127259111@qq.com
 *
 * =====================================================================================
 */
#include <stdio.h>
#include <stdlib.h>


int i = 1;


int main(void)
{
    printf("Hello World\n");

    int a = 1;
    printf("%d \n", a);
    return EXIT_SUCCESS;
}

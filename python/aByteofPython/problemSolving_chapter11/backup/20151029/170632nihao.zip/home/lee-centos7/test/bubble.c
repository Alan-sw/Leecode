#include <stdio.h>
#include <stdlib.h>

void bubble(int a[], int n)
{
    int i = 0, j = 0, temp = 0;
    for(i = 0; i < n; i++) {
        for(j = n - 1; j > 0; j--) {
            if(a[j] < a[j - 1]) {
                temp = a[j];
                a[j] = a[j - 1];
                a[j - 1] = temp;
            }
        }
    }
}

int main(void)
{
    int i = 0;
    int a[] = {2, 4, 1, 0, 3, 9, 5, 7, 6, 8};
    bubble(a, sizeof(a) / sizeof(int));
    for (i = 0; i < 10; ++i) {
        printf("%d   \n", a[i]);
    }
    return EXIT_SUCCESS;
}

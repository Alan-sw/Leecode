#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    printf("hello world\n");
    return EXIT_SUCCESS;
}

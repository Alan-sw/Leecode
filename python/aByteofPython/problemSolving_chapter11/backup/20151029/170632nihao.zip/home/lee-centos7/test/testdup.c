/*
 * =====================================================================================
 *
 *       Filename:  testdup.c
 *
 *    Description:  test the use of dup
 *
 *        Created:  10/12/2015 02:02:35 PM
 *       Compiler:  gcc
 *
 *         Author:  Alan Lee , 1127259111@qq.com
 *
 * =====================================================================================
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(void)
{
    int fd;
    fd = open("./mytest2.txt", O_RDWR | O_CREAT, 0644);
    if (fd == -1) {
        printf("open file error\n");
        return EXIT_FAILURE;
    }

    close(1);
    dup(fd);
    close(fd);

    printf("write to file\n");

    return EXIT_SUCCESS;
}

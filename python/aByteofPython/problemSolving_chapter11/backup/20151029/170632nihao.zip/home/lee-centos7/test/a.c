/*
 * =====================================================================================
 *
 *       Filename:  a.c
 *
 *    Description:  
 *
 *        Created:  10/23/2015 09:22:55 AM
 *       Compiler:  gcc
 *
 *         Author:  Alan Lee , 1127259111@qq.com
 *
 * =====================================================================================
 */
#include <stdio.h>
#include <stdlib.h>

int adddigits(int num)
{
    while (num >= 10) {
        int m = num % 10;
        int n = num / 10;
        num = n + m;
    }
    return num;
    
}

int main()
{   
    printf("the result is : %d\n", adddigits(138));
    
    return 0;
}

/*
 * =====================================================================================
 *
 *       Filename:  min_define.c
 *
 *    Description:  use macro to define min function
 *
 *        Created:  10/10/2015 09:00:28 AM
 *       Compiler:  gcc
 *
 *         Author:  Alan Lee , 1127259111@qq.com
 *
 * =====================================================================================
 */
#include <stdio.h>
#include <stdlib.h>

#define MIN1(A, B) ( (A) < (B) ? (A) : (B) )

//this is standard define
#define MIN2(A, B) ({__typeof__(A) __a = (A); __typeof__(B) __b = (B); __a < __b ? __a : __b;})


int main(void)
{
    int a = 1, b = 6;
    printf("min1 of a++ b++ is : %d\n", MIN1(a++, b++));
    printf("now a is : %d and b is : %d\n", a, b);
    printf("min2 of a++ b++ is : %d\n", MIN2(a++, b++));
    printf("now a is : %d and b is : %d\n", a, b);

    return EXIT_SUCCESS;
}



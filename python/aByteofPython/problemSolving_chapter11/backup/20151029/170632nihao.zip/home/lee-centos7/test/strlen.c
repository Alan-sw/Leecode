/*
 * =====================================================================================
 *
 *       Filename:  strlen.c
 *
 *    Description:  function strlen archieve
 *
 *        Created:  10/09/2015 03:36:14 PM
 *       Compiler:  gcc
 *
 *         Author:  Alan Lee , 1127259111@qq.com
 *
 * =====================================================================================
 */
#include <stdio.h>
#include <stdlib.h>

int testStrlen(const char *s)
{
    const char *str;
    for (str = s; *str != '\0'; str++) {
        ;
    }

    return (str - s);
}

int main(void)
{
    char *sc = "Hello World";
    
    printf("the length of sc is : %d\n", testStrlen(sc));

    return EXIT_SUCCESS;
}
